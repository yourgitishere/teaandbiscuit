package com.dm.api.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dm.api.entity.ArchiveFileSystem;



public interface ArchiveRepository extends JpaRepository<ArchiveFileSystem, Long>{

}
